<template>
  <div class="row" style="margin-top: 15px">
    <NuxtLink class="three columns button button-primary" to="/">
      Home
    </NuxtLink>
    <NuxtLink class="three columns button button-primary" to="/personajes_index">
      Personajes
    </NuxtLink>
    <NuxtLink class="three columns button button-primary" to="/comics_index">
     Comics
    </NuxtLink>
    <NuxtLink class="three columns button button-primary" to="/ilustradores_index">
      Ilustradores
    </NuxtLink>
  </div>
</template>
